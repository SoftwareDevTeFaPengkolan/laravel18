<!DOCTYPE html>
<html>
<head>
	<title>laravel- www.malasngoding.com</title>
</head>
<body>
 
	<h3>www.malasngoding.com</h3>
	<p>Seri Tutorial Laravel Lengkap Dari Dasar</p>
	<p>Ini adalah view blog. ada di route blog.</p>
 
</body>
</html>